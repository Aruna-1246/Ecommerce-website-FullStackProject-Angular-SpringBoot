import { Component, OnInit } from '@angular/core';
import { CartItem } from '../model/cart-model.model';
import { CartService } from '../cart.service';
import { ProductService } from '../product.service';
import { Product } from '../model/product.model';
import { AuthService } from '../services/auth.service';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-cart',
  standalone: false,
  
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {

  cartItems: any[] = [];
  userId: number | null = null;
  totalPrice: number = 0;
  shippingAddress: string = '';

  constructor(private cartService: CartService, private authService: AuthService,
    private orderService: OrderService
  ) { }

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    if (this.userId !== null) {
      this.loadCart();
    } else {
      console.error('User not logged in');
    }
  }

  loadCart(): void {
    if (this.userId !== null) {
      this.cartService.getCartByUser(this.userId).subscribe({
        next: (data) => {
          this.cartItems = data;
          this.calculateTotalPrice();
        },
        error: (error) => {
          console.error('Error loading cart:', error);
        }
      });
    }
  }

  calculateTotalPrice(): void {
    if (this.userId !== null) {
      this.cartService.getTotalPrice(this.userId).subscribe({
        next: (price) => {
          this.totalPrice = price || 0;
        },
        error: (error) => {
          console.error('Error calculating total price:', error);
        }
      });
    }
  }

  
  removeProduct(productId: number): void {
    const userId = this.authService.getUserId();
    if (userId !== null) {
      this.cartService.removeProductFromCart(userId, productId).subscribe(  // Here productId refers to cartitem id of that product
        (response) => {
          console.log('Product removed', response);
          window.alert("Product removed, please refresh to see the changes");
        },
        (error) => {
          console.error('Error removing product:', error);
        }
      );
    } else {
      console.error('User ID is null. Cannot remove product.');
    }
  }

  placeOrder(): void {
    if (this.shippingAddress) {
      this.orderService.createOrderFromCart(this.userId!, this.shippingAddress).subscribe(() => {
        alert('Order placed successfully!');
        this.loadCart(); // Refresh cart after placing order
      });
    } else {
      alert('Please provide a shipping address.');
    }
  }

  clearCart(): void {
    if (this.userId !== null) {
      this.cartService.clearCart(this.userId).subscribe({
        next: () => {
          this.loadCart();
        },
        error: (error) => {
          console.error('Error clearing cart:', error);
        }
      });
    }
  }
}