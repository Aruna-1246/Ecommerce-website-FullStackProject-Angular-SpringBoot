import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { OrderService } from '../order.service';
import { AuthService } from '../services/auth.service';
import { Product } from '../model/product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-orders',
  standalone: false,
  
  templateUrl: './orders.component.html',
  styleUrl: './orders.component.css'
})
export class OrdersComponent implements OnInit {
  selectedProduct: Product | null = null;
  quantity: number = 1;
  totalPrice: number = 0;
  shippingAddress: string = ''; 
  userId: number | null = null;

  constructor(
    private router: Router,
    private http: HttpClient,
    private ordersService: OrderService,
    private authService: AuthService,
    private productService: ProductService
  ) {}

  ngOnInit(): void {
    const selectedProduct = this.productService.getSelectedProduct();
    if (selectedProduct) {
      this.selectedProduct = selectedProduct;
      console.log('Selected Product from service:', this.selectedProduct);
      this.calculateTotal();
    } else {
      alert('Product passed!');
      this.router.navigate(['/']);
    }
  
    this.userId = this.authService.getUserId();
    if (!this.userId) {
      this.router.navigate(['/login']);
    }
  }

  calculateTotal(): void {
    if (this.selectedProduct) {
      this.totalPrice = this.selectedProduct.productDiscountedPrice * this.quantity;
    }
  }

  confirmOrder(): void {
    if (this.selectedProduct && this.userId) {
      const productId = this.selectedProduct.productId!;
      const quantity = this.quantity;

      // Call the backend API to create the order
      this.ordersService.directOrder(this.userId, productId, quantity, this.shippingAddress).subscribe({
        next: (response) => {
          console.log('Order placed successfully', response);
          alert('Order placed successfully');
          this.router.navigate(['/my-orders']);
        },
        error: (error) => {
          console.error('Error placing order', error);
          alert('Order placed successfully');
        }
      });
    } else {
      alert('Please log in first to place an order');
    }
  }
}