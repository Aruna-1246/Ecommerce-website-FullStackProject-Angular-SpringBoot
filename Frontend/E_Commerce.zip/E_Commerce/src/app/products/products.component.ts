import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product.model';
import { CartService } from '../cart.service';
import { ProductService } from '../product.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router'; // Import Router

declare var bootstrap: any;

@Component({
  selector: 'app-products',
  standalone: false,
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
})
export class ProductsComponent implements OnInit {
  searchKeyword: string = '';
  products: Product[] = [];
  filteredProducts: Product[] = [];
  selectedProduct: Product | null = null;
  userId: number | null = null;
  cartMessage: string | null = null;
  currentPage: number = 1;
  totalPages: number = 0;
  pageSize: number = 12;
  selectedQuantity: number = 1;

  constructor(
    private productService: ProductService,
    private cartService: CartService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getAllProducts(this.currentPage - 1, this.pageSize).subscribe({
      next: (data) => {
        this.products = data.content;
        this.filteredProducts = data.content;
        this.totalPages = data.totalPages;
      },
      error: (error) => console.error('Error fetching products', error),
    });
  }

  openProductDetails(product: Product): void {
    this.selectedProduct = product;
    const modal = new bootstrap.Modal(document.getElementById('productDetailModal')!);
    modal.show();
  }

  closeModal(): void {
    this.selectedProduct = null;
    const modal = bootstrap.Modal.getInstance(document.getElementById('productDetailModal')!);
    modal.hide();
  }

  openQuantityModal(product: Product): void {
    this.selectedProduct = product;
    this.selectedQuantity = 1; // Reset quantity each time modal opens
    const modal = new bootstrap.Modal(document.getElementById('quantityModal')!);
    modal.show();
  }

  addToCart(product: Product): void {
    if (this.userId && this.selectedProduct) {
      const userId = this.userId;
      const productId = this.selectedProduct.productId!;
      const quantity = this.selectedQuantity;

      this.cartService.addProductToCart(userId, productId, quantity).subscribe({
        next: () => {
          this.cartMessage = 'Product added to cart';
          setTimeout(() => {
            this.cartMessage = null;
          }, 3000);
          const modal = bootstrap.Modal.getInstance(document.getElementById('quantityModal')!);
          this.closeModal();
        },
        error: (error) => console.error('Error adding to cart', error),
      });
    } else {
      console.error('User not logged in or product not selected');
    }
  }

  buyNow(product: Product): void {
    console.log('Buy Now:', product);
    this.productService.setSelectedProduct(product);
    this.router.navigate(['/orders']);
    this.closeModal();
  }

  searchProducts(): void {
    if (this.searchKeyword) {
      this.filteredProducts = this.products.filter((product) =>
        product.productName?.toLowerCase().includes(this.searchKeyword.toLowerCase()) || 
        product.productDescription?.toLowerCase().includes(this.searchKeyword.toLowerCase())
      );
    } else {
      this.filteredProducts = [...this.products];
    }
  }

  goToNextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.loadProducts();
    }
  }

  goToPreviousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadProducts();
    }
  }  
}
