import { Component } from '@angular/core';
import { Product } from '../model/product.model';
import { ProductService } from '../product.service';
import { ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-product',
  standalone: false,
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
  product: Product = new Product();  // Initialize empty product
  message: string = '';
  isEditMode: boolean = false;
  productForm!: NgForm;

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    const productId = this.route.snapshot.paramMap.get('productId');
    if (productId) {
      this.isEditMode = true;
      this.loadProductDetails(Number(productId));  // Load product for editing
    }
  }

  // Method to add or update the product
  addProduct(): void {
    if (this.isEditMode) {
      // If it's edit mode, update the product
      this.productService.updateProduct(this.product).subscribe({
        next: (response) => {
          this.message = 'Product updated successfully!';
        },
        error: (error) => {
          this.message = 'Failed to update product.';
          console.error(error);
        }
      });
    } else {
      // If it's not edit mode, add the product
      this.productService.addProduct(this.product).subscribe({
        next: (response) => {
          this.message = 'Product added successfully!';
        },
        error: (error) => {
          this.message = 'Failed to add product.';
          console.error(error);
        }
      });
    }
  }

  // Method to load product details for editing
  loadProductDetails(productId: number): void {
    this.productService.getProductById(productId).subscribe({
      next: (product: Product) => {
        this.product = product;
      },
      error: (error) => {
        console.error('Error fetching product details:', error);
      }
    });
  }
}
