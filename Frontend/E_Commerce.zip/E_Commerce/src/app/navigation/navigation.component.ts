import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navigation',
  standalone: false,
  
  templateUrl: './navigation.component.html',
  styleUrl: './navigation.component.css'
})
export class NavigationComponent implements OnInit {
  role: string | null = null;
  isLoggedIn: boolean = false;

  constructor(private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit() {
    // Subscribe to role and user login status
    this.authService.role$.subscribe((role) => {
      this.role = role;
      this.isLoggedIn = !!role; // If role is not null, user is logged in
    });
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}