export interface Orders {
  orderId: number;
  orderStatus: string;
  shippingAddress: string;
  totalPrice: number;
  orderDate: string;
  deliveryDate: string;
  userId:number;
  orderItems: OrderItem[];
}

export interface OrderItem {
  productId: number;
  productName: string;
  quantity: number;
  price: number;
}
