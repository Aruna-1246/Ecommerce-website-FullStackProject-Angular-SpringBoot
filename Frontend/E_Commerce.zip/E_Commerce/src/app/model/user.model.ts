export interface User {
    userId: number;
    username: string;
    password: string;
    role: string;
    phoneNumber: string;
    email: string;
    cartItems?: CartItem[]; // If you have a CartItem type
}

export interface CartItem {
    productId: number;
    productName: string;
    quantity: number;
    price: number;
}
