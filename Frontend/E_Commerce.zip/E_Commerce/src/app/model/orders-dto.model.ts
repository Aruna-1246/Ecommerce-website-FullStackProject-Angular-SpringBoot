export interface OrderItemDTO {
    productId: number;
    productName: string;
    quantity: number;
    price: number;
    userId:number
  }
  
  export interface OrderDTO {
    orderId: number;
    orderStatus: string;
    shippingAddress: string;
    totalPrice: number;
    orderDate: string;
    deliveryDate: string;
    userId: number;
    orderItems: OrderItemDTO[];
  }
  