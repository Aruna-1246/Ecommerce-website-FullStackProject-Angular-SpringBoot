export interface CartItem {
  cartItemId?: number;
  userId: number;
  productId: number;
  productName: string;
  productPrice: number;
  quantity: number;
}
