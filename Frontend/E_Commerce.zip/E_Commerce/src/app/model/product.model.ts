export class Product {
    productId?: number;
    productName: string = '';
    productDescription: string = '';
    productActualPrice: number = 1;
    productDiscountedPrice: number = 1;
    imageUrls?: string;
    stock?: number;
    quantity?: number;
  }
  