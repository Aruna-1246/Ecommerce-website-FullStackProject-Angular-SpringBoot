import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Orders } from './model/orders.model';

@Injectable({
  providedIn: 'root'
})
export class OrderService {


  private baseUrl = 'http://localhost:8080/api/orders';

  constructor(private http: HttpClient) { }

  createOrderFromCart(userId: number, shippingAddress: string): Observable<Orders> {
    return this.http.post<Orders>(`${this.baseUrl}/fromCart?userId=${userId}&shippingAddress=${shippingAddress}`, null);
  }

  directOrder(userId:number, productId: number, quantity:number, shippingAddress: string){
    return this.http.post(`${this.baseUrl}/direct?userId=${userId}&productId=${productId}&quantity=${quantity}&shippingAddress=${shippingAddress}`,{});
  }
  
  getOrdersByUser(userId: number): Observable<any> {
    return this.http.get<Orders[]>(`${this.baseUrl}/user/${userId}`);
  }

  getAllOrders(page: number, size: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/all?page=${page}&size=${size}`);
  }

  // Method to get a specific order by order ID
  getOrderById(orderId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/${orderId}`);
  }

  // Method to cancel an order
  cancelOrder(orderId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/cancel/${orderId}`, null);
  }
  
  // Method to update an order (updating status)
  updateOrderStatus(orderId: number): Observable<any> {
    return this.http.put(`${this.baseUrl}/updateStatus?orderId=${orderId}&status=DELIVERED`, null);
  }
  
}

