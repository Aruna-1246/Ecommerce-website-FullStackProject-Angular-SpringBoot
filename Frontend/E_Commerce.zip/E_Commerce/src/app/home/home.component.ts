import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  products: any[] = [];
  currentPage: number = 1;   // Set initial page
  totalPages: number = 0;    // Total number of pages
  pageSize: number = 12;     // Number of products per page

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getAllProducts(this.currentPage - 1, this.pageSize).subscribe((data: any) => {
      this.products = data.content;
      this.totalPages = data.totalPages;
    });
  }

  goToNextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.loadProducts();  // Load products for the next page
    }
  }

  goToPreviousPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.loadProducts();  // Load products for the previous page
    }
  }
}
