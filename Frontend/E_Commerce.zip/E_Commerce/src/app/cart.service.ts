import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { CartItem } from './model/cart-model.model';
import { Orders } from './model/orders.model';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  private baseUrl = 'http://localhost:8080/api/cart';

  constructor(private http: HttpClient) { }

  addProductToCart(userId: number, productId: number, quantity: number = 1): Observable<any> {
    return this.http.post(`${this.baseUrl}/add/${userId}/${productId}?quantity=${quantity}`, {});
  }

  getCartByUser(userId: number): Observable<any> {
    return this.http.get<CartItem>(`${this.baseUrl}/${userId}`);
  }

  setQuantity(userId: number, productId: number, quantity: number): Observable<CartItem> {
    return this.http.put<CartItem>(`${this.baseUrl}/setQuantity/${userId}/${productId}?quantity=${quantity}`, {});
  }

  removeProductFromCart(userId: number, productId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/remove/${userId}/${productId}`);
  }

  getTotalPrice(userId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/total/${userId}`);
  }

  clearCart(userId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/clear/${userId}`);
  }
}
