import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from '../model/product.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  standalone: false,
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  errorMessage: string = '';
  selectedImageUrl: string = ''; 
  isImageModalVisible: boolean = false;
  searchKeyword: string = '';  // Bind search input
  currentPage: number = 0;  // Current page
  totalPages: number = 0;   // Total number of pages
  pageSize: number = 10;    // Products per page

  constructor(private productService: ProductService, private router: Router) {}

  ngOnInit(): void {
    this.getAllProducts();
  }

  // Fetch products with pagination
  getAllProducts(): void {
    this.productService.getAllProducts(this.currentPage, this.pageSize).subscribe(
      (data: any) => {  
        this.products = data.content; 
        this.filteredProducts = this.products; 
        this.totalPages = data.totalPages;  
      },
      (error) => {
        this.errorMessage = 'Error fetching products: ' + error.message;
      }
    );
  }

  // Search products by keyword
  searchProducts(): void {
    if (this.searchKeyword) {
      this.filteredProducts = this.products.filter((product) =>
        (product.productId?.toString().includes(this.searchKeyword)) ||  // Use optional chaining here
        product.productName?.toLowerCase().includes(this.searchKeyword.toLowerCase()) || 
        product.productDescription?.toLowerCase().includes(this.searchKeyword.toLowerCase())
      );
    } else {
      this.filteredProducts = [...this.products]; // Reset to original products when no search keyword
    }
  }

  // Edit product details
  editProductDetails(productId: any) {
    this.router.navigate(['/add-product', { productId: productId }]);
  }

  // Open image modal
  openImageModal(imageUrls: any): void {
    this.selectedImageUrl = imageUrls;
    this.isImageModalVisible = true;
  }

  // Close image modal
  closeImageModal(): void {
    this.isImageModalVisible = false;
  }

  // Delete product
  deleteProduct(productId: any): void {
    this.productService.deleteProduct(productId).subscribe(
      () => {
        this.products = this.products.filter(product => product.productId !== productId);
        this.filteredProducts = this.filteredProducts.filter(product => product.productId !== productId);
      },
      (error) => {
        console.error('Error deleting product', error);
        window.alert("If the product is already ordered by any user, it cannot be deleted. Otherwise it is deleted.Please refresh the page to see the changes");
      }
    );
  }

  // Navigate to the next page
  goToNextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.getAllProducts();
    }
  }

  // Navigate to the previous page
  goToPreviousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.getAllProducts();
    }
  }
}
