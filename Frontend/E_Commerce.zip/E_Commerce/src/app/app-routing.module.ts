import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { AddProductComponent } from './add-product/add-product.component';
import { ProductListComponent } from './product-list/product-list.component';
import { HomeComponent } from './home/home.component';
import { OrdersComponent } from './orders/orders.component';
import { ProfileComponent } from './profile/profile.component';
import { CartComponent } from './cart/cart.component';
import { UserListComponent } from './user-list/user-list.component';
import { OrderListComponent } from './order-list/order-list.component';
import { ProductsComponent } from './products/products.component';
import { AuthGuard } from './services/auth.guard';
import { MyOrdersComponent } from './my-orders/my-orders.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component:RegisterComponent},
  { path: 'add-product', component:AddProductComponent, canActivate: [AuthGuard]},
  { path: 'product-list', component:ProductListComponent, canActivate: [AuthGuard]},
  { path: 'home', component:HomeComponent},
  { path: 'orders', component: OrdersComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'cart', component: CartComponent },
  { path: 'user-list', component: UserListComponent,  canActivate: [AuthGuard] },
  { path: 'order-list', component: OrderListComponent,  canActivate: [AuthGuard] },
  { path: 'products', component:ProductsComponent },
  { path: 'my-orders', component:MyOrdersComponent},
  { path: '**', redirectTo: '/home' } ,
 
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
