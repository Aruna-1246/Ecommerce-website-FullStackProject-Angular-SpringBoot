import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  // Handle form submission
  onSubmit(): void {
    // Call the login method from AuthService
    this.authService.login(this.username, this.password).subscribe({
      next: () => {
        // After successful login, fetch the current user details (role and userId)
        this.authService.getCurrentUser();

        // Log the role and userId to the console
        this.authService.role$.subscribe({
          next: (role) => {
            console.log('Logged in Role:', role);  // Log role
            if (role) {
              this.authService.userId$.subscribe({
                next: (userId) => {
                  console.log('Logged in UserId:', userId);  // Log userId
                },
                error: () => {
                  console.error('Failed to fetch UserId');
                },
              });

              // Based on the role, navigate to the respective page
              if (role === 'admin') {
                this.router.navigate(['/products']);
              } else if (role === 'user') {
                this.router.navigate(['/products']);
              } else {
                this.errorMessage = 'Unexpected role';
              }
            }
          },
          error: () => {
            this.errorMessage = 'Failed to fetch role';
          },
        });
      },
      error: (error) => {
        // Handle login failure
        console.error('Login failed', error);
        this.errorMessage = 'Invalid credentials';
      },
    });
  }

  // Redirect to the registration page
  register(): void {
    this.router.navigate(['/register']);
  }
}