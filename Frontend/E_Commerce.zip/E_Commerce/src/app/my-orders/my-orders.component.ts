import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { Orders } from '../model/orders.model';

@Component({
  selector: 'app-my-orders',
  standalone: false,
  
  templateUrl: './my-orders.component.html',
  styleUrl: './my-orders.component.css'
})
export class MyOrdersComponent implements OnInit {
  orders: Orders[] = [];
  userId: number | null = null;

  constructor(private orderService: OrderService, private authService: AuthService) {}

  ngOnInit(): void {
    this.userId = this.authService.getUserId();
    if (this.userId !== null) {
      this.loadOrders(this.userId);
    } else {
      console.error('User ID is null');
    }
    
  }

  loadOrders(userId: number): void {
    this.orderService.getOrdersByUser(userId).subscribe({
      next: (data) => {
        console.log('Orders:', data);
        this.orders = data;  // Set orders to the received data
      },
      error: (err) => {
        console.error('Error fetching orders:', err);
      }
    });
  }

  cancelOrder(orderId: number): void {
    console.log('Cancel order method called with orderId:', orderId);
    this.orderService.cancelOrder(orderId).subscribe({
        next: () => {
            window.alert('Order cancelled successfully');
        },
        error: (error) => {
            window.alert('Order cancelled successfully, refresh the page');
        }
    });
}

}