import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';
import { OrderDTO } from '../model/orders-dto.model';

@Component({
  selector: 'app-order-list',
  standalone: false,
  
  templateUrl: './order-list.component.html',
  styleUrl: './order-list.component.css'
})
export class OrderListComponent implements OnInit {

  orders: OrderDTO[] = [];
  currentPage: number = 0;
  totalPages: number = 0;
  pageSize: number = 10;

  constructor(private orderService: OrderService) { }

  ngOnInit(): void {
    this.loadOrders();
  }

  loadOrders(): void {
    this.orderService.getAllOrders(this.currentPage, this.pageSize).subscribe(data => {
      this.orders = data.content;
      this.totalPages = data.totalPages;
    });
  }

  updateOrderStatus(orderId: number): void {
    this.orderService.updateOrderStatus(orderId).subscribe({
      next: () => {
        console.log(`Order ${orderId} status updated.`);
        window.alert("Order status update, please refresh the page");
        this.loadOrders();
      },
      error: (error) => window.alert("Order status update, please refresh the page")
    });
  }

  goToNextPage(): void {
    if (this.currentPage < this.totalPages - 1) {
      this.currentPage++;
      this.loadOrders();
    }
  }

  goToPreviousPage(): void {
    if (this.currentPage > 0) {
      this.currentPage--;
      this.loadOrders();
    }
  }
}
