import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { User } from '../model/user.model';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private apiUrl = 'http://localhost:8080/auth';
  private roleSubject = new BehaviorSubject<string | null>(null);
  private userIdSubject = new BehaviorSubject<number | null>(null);
  role$ = this.roleSubject.asObservable();
  userId$ = this.userIdSubject.asObservable();

  constructor(private http: HttpClient) {}

  // Login method
  login(username: string, password: string): Observable<void> {
    return this.http.post<void>(`${this.apiUrl}/login`, { username, password }, { withCredentials: true }).pipe(
      catchError(this.handleError)
    );
  }

  // Logout method
  logout(): void {
    this.http.post(`${this.apiUrl}/logout`, {}, { withCredentials: true }).pipe(
      catchError(this.handleError)
    ).subscribe({
      next: () => {
        this.clearSession();
      },
      error: () => {
        // Even if an error occurs, clear the session locally
        this.clearSession();
      }
    });
  }

  // Fetch the role and userId from the session and update observables
  getCurrentUser(): void {
    this.http.get<any>(`${this.apiUrl}/currentUser`, { withCredentials: true }).pipe(
      catchError(this.handleError)
    ).subscribe({
      next: (user) => {
        if (user && user.userId && user.role) {
          this.userIdSubject.next(user.userId);
          this.roleSubject.next(user.role);
          sessionStorage.setItem('userId', user.userId.toString());
          sessionStorage.setItem('role', user.role);
        } else {
          this.clearSession();
        }
      },
      error: () => {
        this.clearSession();
      }
    });
  }

  // Get role from sessionStorage
  getRole(): string | null {
    return sessionStorage.getItem('role');
  }

  // Get userId from sessionStorage
  getUserId(): number | null {
    const userId = sessionStorage.getItem('userId');
    return userId ? parseInt(userId, 10) : null;
  }

  // Handle errors
  private handleError(error: HttpErrorResponse): Observable<never> {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      // Client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side error
      if (error.status === 0) {
        errorMessage = 'Unable to connect to the server. Please check your network.';
      } else if (error.status === 401) {
        errorMessage = 'Unauthorized. Please check your credentials.';
      } else if (error.status === 403) {
        errorMessage = 'Forbidden. You don’t have permission to access.';
      } else {
        errorMessage = `Server error: ${error.message}`;
      }
    }
    console.error(errorMessage);
    return throwError(errorMessage);
  }

  isLoggedIn(): boolean {
    return !!this.roleSubject.value;  // If there's a role, the user is logged in
  }
  // Clear session storage and subjects
  private clearSession() {
    this.roleSubject.next(null);
    this.userIdSubject.next(null);
    sessionStorage.removeItem('userId');
    sessionStorage.removeItem('role');
  }

  getAllUsers(): Observable<any> {
    return this.http.get(`${this.apiUrl}/getAllUsers`);
  }

  getUserById(userId: number): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/${userId}`);
}
}
