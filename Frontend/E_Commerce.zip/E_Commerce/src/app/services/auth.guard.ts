import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root',
})
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> | Promise<boolean> | boolean {
    // Check if the user is logged in
    const isLoggedIn = this.authService.isLoggedIn();
    const role = this.authService.getRole();

    // If logged in as admin, allow access to admin pages
    if (isLoggedIn && role === 'admin') {
      return true;
    }

    // If logged in as a regular user, redirect to home page
    if (isLoggedIn && role !== 'admin') {
      this.router.navigate(['/']);
      return false;
    }

    // If not logged in, redirect to login page
    this.router.navigate(['/login']);
    return false;
  }
}
