import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { Product } from './model/product.model';
import { Page } from './model/page.model';


@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private baseUrl = 'http://localhost:8080/api/products'; // Your backend API endpoint

  constructor(private http: HttpClient) {}

  /**
   * Get all products with pagination
   * @param page Current page number
   * @param size Number of products per page
   */
  getAllProducts(page: number = 0, size: number = 10): Observable<any> {
    const params = new HttpParams()
      .set('page', page.toString())
      .set('size', size.toString());

    return this.http.get<any>(`${this.baseUrl}/getAllProducts`, { params });
  }

  searchProducts(keyword: string, page: number, size: number): Observable<Page<Product>> {
    const params = new HttpParams()
      .set('keyword', keyword)
      .set('page', page.toString())
      .set('size', size.toString());
    return this.http.get<Page<Product>>(`${this.baseUrl}/api/products/search?keyword=${keyword}`);
  }
  /**
   * Get product details by ID
   * @param productId Product ID
   */
  getProductById(productId: number): Observable<Product> {
    return this.http.get<Product>(`${this.baseUrl}/getProductDetailsById/${productId}`);
  }

  /**
   * Add a new product
   * @param product Product object to add
   */
  addProduct(product: Product): Observable<Product> {
    return this.http.post<Product>(`${this.baseUrl}/addNewProduct`, product);
  }

  /**
   * Update product details
   * @param product Product object with updated details
   */
  updateProduct(product: Product): Observable<Product> {
    return this.http.put<Product>(`${this.baseUrl}/updateProductDetails/${product.productId}`, product);
  }

  /**
   * Delete a product by ID
   * @param productId Product ID to delete
   */
  deleteProduct(productId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/deleteProductDetails/${productId}`);
  }

  private selectedProductSource = new BehaviorSubject<Product | null>(null);
  selectedProduct$ = this.selectedProductSource.asObservable();

  setSelectedProduct(product: Product): void {
    this.selectedProductSource.next(product);
  }

  getSelectedProduct(): Product | null {
    return this.selectedProductSource.value;
  }
}
