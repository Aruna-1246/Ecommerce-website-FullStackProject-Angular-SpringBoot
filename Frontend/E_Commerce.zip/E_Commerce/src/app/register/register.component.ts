import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  standalone: false,
  
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  username: string = '';
  email: string = '';
  phoneNumber: string = '';
  role: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private userService: UserService, private router: Router) {}

  onRegisterSubmit() {
    const user = {
      username: this.username,
      email: this.email,
      phoneNumber: this.phoneNumber,
      role: this.role,
      password: this.password
    };

    this.userService.register(user).subscribe(
      response => {
        alert(response.message); // Show success message
        this.router.navigate(['/login']); // Navigate to login on success
      },
      error => {
        if (error.status === 400) {
          this.errorMessage = error.error.message; // Display backend error message
        } else {
          this.errorMessage = 'An unexpected error occurred. Please try again.';
        }
      }
    );
  }

  goLog() {
    this.router.navigate(['/login']);
  }
}
