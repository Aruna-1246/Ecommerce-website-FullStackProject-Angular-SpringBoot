package com.ecom.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

@Entity
public class Product {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)	
	private Long productId;
	
	@NotBlank(message = "Product name is mandatory")
	@Pattern(regexp = "^[A-Za-z0-9 _@#-]+$", message = "Product name must contain only alphabets, numbers, spaces, and the special characters _ - @ #")
    @Size(min = 2, max = 40, message = "Product name must be between 2 and 40 characters")
	@Column(name = "productName")
    private String productName;

	@NotBlank(message = "Product description is mandatory")
    @Size(min = 2, max = 2000, message = "Product description must be between 2 and 2000 characters")
	@Column(name = "productDescription")
    private String productDescription;

    @Positive(message = "Actual price must be positive")
    @NotNull(message = "Product actual price is mandatory")
    @Column(name = "productActualPrice")
    private Double productActualPrice;

    @Positive(message = "Discounted price must be positive")
    @NotNull(message = "Product discounted price is mandatory")
    @Column(name = "productDiscountedPrice")
    private Double productDiscountedPrice;
    
    @Lob
    @Column(columnDefinition = "TEXT")
    @NotBlank(message = "Image URLs cannot be empty")
    private String imageUrls;
    
    @Positive(message = "Number of stock must be in positive value")
    @Column(name = "stock")
    private int stock;

    public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public Double getProductActualPrice() {
		return productActualPrice;
	}

	public void setProductActualPrice(Double productActualPrice) {
		this.productActualPrice = productActualPrice;
	}

	public Double getProductDiscountedPrice() {
		return productDiscountedPrice;
	}

	public void setProductDiscountedPrice(Double productDiscountedPrice) {
		this.productDiscountedPrice = productDiscountedPrice;
	}

	public String getImageUrls() {
		return imageUrls;
	}

	public void setImageUrls(String imageUrls) {
		this.imageUrls = imageUrls;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	
    
}