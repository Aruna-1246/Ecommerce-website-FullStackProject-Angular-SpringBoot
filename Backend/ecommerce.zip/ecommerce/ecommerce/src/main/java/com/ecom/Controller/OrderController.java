package com.ecom.Controller;

import com.ecom.DTO.OrderDTO;
import com.ecom.Entity.Orders;
import com.ecom.Service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Sort;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/orders")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Create a new order
    @PostMapping("/create")
    public ResponseEntity<Orders> createOrder(@RequestParam Long userId, @RequestParam String shippingAddress) {
        try {
            Orders orders = orderService.createOrder(userId, shippingAddress);
            return ResponseEntity.ok(orders);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (IllegalStateException e) {
            return ResponseEntity.status(409).body(null); // Conflict for out-of-stock
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    // Directly make orders without reaching cart
    @PostMapping("/direct")
    public Orders createDirectOrder(@RequestParam Long userId,
                                    @RequestParam Long productId,
                                    @RequestParam int quantity,
                                    @RequestParam String shippingAddress) {
        return orderService.createDirectOrder(userId, productId, quantity, shippingAddress);
    }
    
    // Get orders by user ID
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<OrderDTO>> getOrdersByUser(@PathVariable Long userId) {
        try {
            List<OrderDTO> orders = orderService.getOrdersByUserId(userId);
            return ResponseEntity.ok()
                    .header("Content-Type", "application/json")
                    .body(orders);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    
    // Updating the order status to delivered
    @PutMapping("/updateStatus")
    public ResponseEntity<?> updateOrderStatus(
            @RequestParam Long orderId, 
            @RequestParam String status) {
        try {
            Orders updatedOrder = orderService.updateOrderStatus(orderId, status);
            return ResponseEntity.ok(updatedOrder);
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
    
    @GetMapping("/all")
    public ResponseEntity<Page<OrderDTO>> getOrders(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size,
        @RequestParam(defaultValue = "orderDate,desc") String[] sort) {

        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.desc(sort[0])));
        Page<OrderDTO> ordersPage = orderService.getAllOrders(pageable);
        return ResponseEntity.ok()
                .header("Content-Type", "application/json")
                .body(ordersPage);
    }
    
    // Cancel order
    @PutMapping("/cancel/{orderId}")
    public ResponseEntity<Orders> cancelOrder(@PathVariable Long orderId) {
        Orders cancelledOrder = orderService.cancelOrder(orderId);
        return ResponseEntity.ok(cancelledOrder);
    }
    
    @PostMapping("/fromCart")
    public ResponseEntity<Orders> createOrderFromCart(@RequestParam Long userId, @RequestParam String shippingAddress) {
        try {
            Orders order = orderService.createOrderFromCart(userId, shippingAddress);
            return ResponseEntity.ok(order);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }
}
