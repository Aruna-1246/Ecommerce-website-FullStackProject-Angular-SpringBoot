package com.ecom.Service;

import com.ecom.Entity.CartItem;
import com.ecom.Entity.Product;
import com.ecom.Entity.User;
import com.ecom.Exception.CartItemNotFoundException;
import com.ecom.Exception.ResourceNotFoundException;
import com.ecom.Repository.CartRepository;
import com.ecom.Repository.ProductRepository;
import com.ecom.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public CartItem addProductToCart(Long userId, Long productId, Integer quantity) {
    	if (quantity == null || quantity <= 0) {
            quantity = 1; // Default quantity to 1 if not provided or invalid
        }
        Optional<User> userOptional = userRepository.findById(userId);
        Optional<Product> productOptional = productRepository.findById(productId);

        if (userOptional.isEmpty() || productOptional.isEmpty()) {
            throw new IllegalArgumentException("Invalid user or product ID");
        }

        User user = userOptional.get();
        Product product = productOptional.get();
        

        Optional<CartItem> existingCartItem = cartRepository.findByUserAndProduct(user, product);
        if (existingCartItem.isPresent()) {
            CartItem cartItem = existingCartItem.get();
            cartItem.setQuantity(cartItem.getQuantity() + quantity);
            return cartRepository.save(cartItem);
        }

        CartItem cartItem = new CartItem();
        cartItem.setUser(user);
        cartItem.setProduct(product);
        cartItem.setQuantity(quantity);
        
        cartItem.setUsername(user.getUsername()); 
        cartItem.setProductname(product.getProductName());
        return cartRepository.save(cartItem);
    }

    public List<CartItem> getCartByUser(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
        return cartRepository.findAllByUser(user);
    }

    public CartItem increaseQuantity(Long userId, Long productId) {
        CartItem cartItem = findCartItem(userId, productId);
        cartItem.setQuantity(cartItem.getQuantity() + 1);
        return cartRepository.save(cartItem);
    }

    public CartItem decreaseQuantity(Long userId, Long productId) {
        CartItem cartItem = findCartItem(userId, productId);
        if (cartItem.getQuantity() > 1) {
            cartItem.setQuantity(cartItem.getQuantity() - 1);
        } else {
            cartRepository.delete(cartItem);
            return null; // Or throw a custom exception if preferred
        }
        return cartRepository.save(cartItem);
    }

    public void removeItemFromCart(Long userId, Long cartItemId) {
        // Fetch the cart item to validate the user
        CartItem cartItem = cartRepository.findById(cartItemId)
                            .orElseThrow(() -> new ResourceNotFoundException("Cart item not found"));
        
        // Check if the cart item belongs to the provided userId
        if (!cartItem.getUser().getUserId().equals(userId)) {
            throw new IllegalArgumentException("Cart item does not belong to the user");
        }

        // Proceed with deletion if validation passes
        cartRepository.deleteById(cartItemId);
    }


    public Double getTotalPrice(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
        List<CartItem> cartItems = cartRepository.findAllByUser(user);
        return cartItems.stream()
                .mapToDouble(cartItem -> cartItem.getProduct().getProductDiscountedPrice() * cartItem.getQuantity())
                .sum();
    }

    public void clearCart(Long userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
        List<CartItem> cartItems = cartRepository.findAllByUser(user);
        cartRepository.deleteAll(cartItems);
    }

    private CartItem findCartItem(Long userId, Long productId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("User not found"));
        Product product = productRepository.findById(productId).orElseThrow(() -> new IllegalArgumentException("Product not found"));
        return cartRepository.findByUserAndProduct(user, product)
                .orElseThrow(() -> new CartItemNotFoundException("Cart item not found"));
    }
    
    public CartItem setQuantity(Long userId, Long productId, Integer quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }

        // Find the cart item based on user ID and product ID
        CartItem cartItem = findCartItem(userId, productId);
        cartItem.setQuantity(quantity);  // Set the new quantity

        // Save and return the updated cart item
        return cartRepository.save(cartItem);
    }
}
