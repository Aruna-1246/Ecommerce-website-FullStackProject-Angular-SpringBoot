package com.ecom.Repository;

import com.ecom.Entity.CartItem;
import com.ecom.Entity.Product;
import com.ecom.Entity.User;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface CartRepository extends JpaRepository<CartItem, Long> {
	Optional<CartItem> findByUserAndProduct(User user, Product product);
	List<CartItem> findAllByUser(User user);
}