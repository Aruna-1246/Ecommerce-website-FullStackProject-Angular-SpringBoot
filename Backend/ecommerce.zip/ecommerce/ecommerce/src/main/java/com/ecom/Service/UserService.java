package com.ecom.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.ecom.Entity.User;
import com.ecom.Exception.UsernameAlreadyExistsException;
import com.ecom.Repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public void registerUser(User user) {
        try {
            if (userRepository.existsByUsername(user.getUsername())) {
                throw new UsernameAlreadyExistsException("The username '" + user.getUsername() + "' is already taken. Please choose a different username.");
            }
            if (userRepository.existsByEmail(user.getEmail())) {
                throw new UsernameAlreadyExistsException("The email '" + user.getEmail() + "' is already in use. Please use a different email address.");
            }
            if (userRepository.existsByPhoneNumber(user.getPhoneNumber())) {
                throw new UsernameAlreadyExistsException("The phone number '" + user.getPhoneNumber() + "' is already associated with another account. Please use a different phone number.");
            }
            userRepository.save(user);
        } catch (DataIntegrityViolationException e) {
            throw new UsernameAlreadyExistsException("An error occurred while processing your request. Please try again.");
        }
    }
    
    public List<User> getAllUsers() {
        try {
            return userRepository.findAll(); // Fetch all users from the repository
        } catch (Exception e) {
            throw new RuntimeException("Error fetching all users: " + e.getMessage());
        }
    }
    
    public User getUserById(Long userId) {
        return userRepository.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("User not found with id: " + userId));
    }
}
