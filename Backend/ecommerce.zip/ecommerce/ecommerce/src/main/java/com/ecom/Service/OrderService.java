package com.ecom.Service;

import com.ecom.DTO.OrderDTO;
import com.ecom.DTO.OrderItemDTO;
import com.ecom.Entity.*;
import com.ecom.Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Transactional
    public Orders createOrder(Long userId, String shippingAddress) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        List<CartItem> cartItems = cartRepository.findAllByUser(user);

        // Check and update stock for each cart item
        for (CartItem cartItem : cartItems) {
            Product product = cartItem.getProduct();
            if (product.getStock() < cartItem.getQuantity()) {
                throw new IllegalStateException("Product " + product.getProductName() + " is out of stock.");
            }
            product.setStock(product.getStock() - cartItem.getQuantity());
            productRepository.save(product);
        }

        // Create the order
        Orders order = new Orders();
        order.setUser(user);
        order.setShippingAddress(shippingAddress);
        order.setOrderStatus("PENDING");
        order.setOrderDate(LocalDate.now());
        order.setDeliveryDate(LocalDate.now().plusDays(5));

        double totalPrice = 0;
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(cartItem.getProduct().getProductDiscountedPrice());

            // Set the reference of Orders in OrderItem
            orderItem.setOrders(order); // Ensuring orderItem knows which order it belongs to

            orderItems.add(orderItem);
            totalPrice += orderItem.getPrice() * orderItem.getQuantity();
        }
        order.setTotalPrice(totalPrice);
        order.setOrderItems(orderItems);

        // Persist the order, which will cascade to orderItems
        orderRepository.save(order);

        // Clear the user's cart after placing the order
        cartRepository.deleteAll(cartItems);

        return order;
    }
    
    // Get the orders of each user by userId
    public List<Orders> getOrdersByUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        return orderRepository.findByUser(user);
    }
    
    // Directly ordering without reaching the cart
    
    @Transactional
    public Orders createDirectOrder(Long userId, Long productId, int quantity, String shippingAddress) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        // Check stock availability
        if (product.getStock() < quantity) {
            throw new IllegalStateException("Product " + product.getProductName() + " is out of stock.");
        }

        // Update product stock
        product.setStock(product.getStock() - quantity);
        productRepository.save(product);

        // Create a new order
        Orders order = new Orders();
        order.setUser(user);
        order.setShippingAddress(shippingAddress);
        order.setOrderStatus("PENDING");
        order.setOrderDate(LocalDate.now());
        order.setDeliveryDate(LocalDate.now().plusDays(5));

        // Create an order item for the specified product
        OrderItem orderItem = new OrderItem();
        orderItem.setProduct(product);
        orderItem.setQuantity(quantity);
        orderItem.setPrice(product.getProductDiscountedPrice());
        orderItem.setOrders(order); // Link the order item to the order

        // Set order details
        order.setOrderItems(Collections.singletonList(orderItem));
        order.setTotalPrice(orderItem.getPrice() * quantity);

        // Save the order
        orderRepository.save(order);

        return order;
    }
    
    // Change the order status to delivered by admin
    @Transactional
    public Orders updateOrderStatus(Long orderId, String status) {
        Orders order = orderRepository.findById(orderId)
            .orElseThrow(() -> new IllegalArgumentException("Order not found"));

        // Check if the order is already canceled
        if (order.getOrderStatus().equals("CANCELLED")) {
            throw new IllegalStateException("Order already cancelled, cannot deliver");
        }
        
        if (order.getOrderStatus().equals("DELIVERED")) {
        	throw new IllegalStateException("Order already delivered");
        }

        // Validate the status change
        if (!status.equals("DELIVERED") && !status.equals("PENDING") && !status.equals("CANCELLED")) {
            throw new IllegalArgumentException("Invalid order status");
        }

        order.setOrderStatus(status);
        return orderRepository.save(order);
    }

    
    // Cancel order
    @Transactional
    public Orders cancelOrder(Long orderId) {
        Orders order = orderRepository.findById(orderId)
            .orElseThrow(() -> new IllegalArgumentException("Order not found"));

        if (!order.getOrderStatus().equals("PENDING")) {
            throw new IllegalStateException("Only pending orders can be cancelled.");
        }

        order.setOrderStatus("CANCELLED");
        return orderRepository.save(order);
    }
    
    public Page<OrderDTO> getAllOrders(Pageable pageable) {
        Page<Orders> ordersPage = orderRepository.findAll(pageable);
        List<OrderDTO> orderDTOs = ordersPage.getContent().stream()
            .map(this::convertToOrderDTO)
            .collect(Collectors.toList());
        return new PageImpl<>(orderDTOs, pageable, ordersPage.getTotalElements());
    }
    
    private OrderDTO convertToOrderDTO(Orders order) {
        OrderDTO orderDTO = new OrderDTO();
        orderDTO.setOrderId(order.getOrderId());
        orderDTO.setUserId(order.getUser().getUserId());
        orderDTO.setOrderStatus(order.getOrderStatus());
        orderDTO.setShippingAddress(order.getShippingAddress());
        orderDTO.setTotalPrice(order.getTotalPrice());
        orderDTO.setOrderDate(order.getOrderDate());
        orderDTO.setDeliveryDate(order.getDeliveryDate());
        orderDTO.setOrderItems(order.getOrderItems().stream()
            .map(this::convertToOrderItemDTO)
            .collect(Collectors.toList()));
        return orderDTO;
    }

    
 // Add this method to convert OrderItem entity to OrderItemDTO
    private OrderItemDTO convertToOrderItemDTO(OrderItem orderItem) {
        OrderItemDTO orderItemDTO = new OrderItemDTO();
        orderItemDTO.setProductId(orderItem.getProduct().getProductId());
        orderItemDTO.setProductName(orderItem.getProduct().getProductName());
        orderItemDTO.setQuantity(orderItem.getQuantity());
        orderItemDTO.setPrice(orderItem.getPrice());
        return orderItemDTO;
    }

    // Modify existing method to return OrderDTO instead of Orders
    public List<OrderDTO> getOrdersByUserId(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        return orderRepository.findByUser(user).stream()
                .map(this::convertToOrderDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional
    public Orders createOrderFromCart(Long userId, String shippingAddress) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));

        List<CartItem> cartItems = cartRepository.findAllByUser(user);

        // Create order and order items
        Orders order = new Orders();
        order.setUser(user);
        order.setShippingAddress(shippingAddress);
        order.setOrderStatus("PENDING");
        order.setOrderDate(LocalDate.now());
        order.setDeliveryDate(LocalDate.now().plusDays(5));

        double totalPrice = 0;
        List<OrderItem> orderItems = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            OrderItem orderItem = new OrderItem();
            orderItem.setProduct(cartItem.getProduct());
            orderItem.setQuantity(cartItem.getQuantity());
            orderItem.setPrice(cartItem.getProduct().getProductDiscountedPrice());
            orderItem.setOrders(order); // Link order item to the order

            orderItems.add(orderItem);
            totalPrice += orderItem.getPrice() * orderItem.getQuantity();
        }
        order.setTotalPrice(totalPrice);
        order.setOrderItems(orderItems);

        // Save order and clear cart
        orderRepository.save(order);
        cartRepository.deleteAll(cartItems); // Clear the cart

        return order;
    }
}
