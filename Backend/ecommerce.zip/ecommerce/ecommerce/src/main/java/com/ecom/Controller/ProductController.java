package com.ecom.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.ecom.Entity.Product;
import com.ecom.Service.ProductService;

import java.util.Optional;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping(value = "/addNewProduct", consumes = "application/json")
    public ResponseEntity<?> addNewProduct(@RequestBody Product product) {
        try {
            Product newProduct = productService.addProduct(product);
            return ResponseEntity.ok(newProduct);
        } catch (Exception e) {
            return handleException(e, "Error adding new product");
        }
    }

    @GetMapping("/getAllProducts")
    public Page<Product> getProducts(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "10") int size,
        @RequestParam(defaultValue = "productName,asc") String[] sort) {

        Sort.Direction direction = Sort.Direction.fromString(sort[1]);
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, "productId")); // Displays the page by the asc order of productId
        return productService.getAllProducts(pageable);
    }

    @GetMapping("/getProductDetailsById/{productId}")
    public ResponseEntity<?> getProductDetailsById(@PathVariable Long productId) {
        try {
            Optional<Product> product = productService.getProductDetailsById(productId);

            // If product is found, return it
            if (product.isPresent()) {
                return ResponseEntity.ok(product.get());
            } else {
                // If product is not found, return a 404 status with an error message
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                     .body("Product not found with ID: " + productId);
            }

        } catch (Exception e) {
            return handleException(e, "Error fetching product details by ID");
        }
    }

    @PutMapping("/updateProductDetails/{productId}")
    public ResponseEntity<?> updateProductDetails(@PathVariable("productId") Long productId, @RequestBody Product product) {
        try {
            Product updatedProduct = productService.updateProductDetails(productId, product);
            return ResponseEntity.ok(updatedProduct);
        } catch (Exception e) {
            return handleException(e, "Error updating product details");
        }
    }

    @DeleteMapping("/deleteProductDetails/{productId}")
    public ResponseEntity<?> deleteProductDetails(@PathVariable("productId") Long productId) {
        try {
            productService.deleteProductDetails(productId);
            return ResponseEntity.ok("Product deleted successfully");
        } catch (Exception e) {
            return handleException(e, "Error deleting product");
        }
    }

    private ResponseEntity<?> handleException(Exception e, String customMessage) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(customMessage + ": " + e.getMessage());
    }
    
    @GetMapping("/search")
    public Page<Product> searchProducts(@RequestParam("keyword") String keyword, Pageable pageable) {
        return productService.searchProducts(keyword, pageable);
    }
}
